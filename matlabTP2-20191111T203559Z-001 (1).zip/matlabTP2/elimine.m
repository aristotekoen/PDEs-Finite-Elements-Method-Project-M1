function [tilde_AA,tilde_LL] = elimine(AA,LL,Refneu)
% Pseudo elimination des noeuds i du bord (i.e /refneu(i) == 1)
Nbpt = length(Refneu);
tilde_AA = AA;
tilde_LL = LL;
for l = 1:Nbpt
    if Refneu(l)==1 %le sommet appartient au bord dOmega_1 et pas au bord dOmega_2
        tilde_LL(l) = 0;
        tilde_AA(l,:) = zeros(1,Nbpt);
        tilde_AA(l,l) = 1;
    end
end


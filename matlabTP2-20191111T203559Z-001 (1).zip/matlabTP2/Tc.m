function val = Tc(x,y)
% Temperature de reference du climatiseur
val = 290;
end


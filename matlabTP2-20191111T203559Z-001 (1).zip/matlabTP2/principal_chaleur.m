% =====================================================
%
% principal_chaleur;
%
% une routine pour la mise en oeuvre des EF P1 Lagrange
% pour 
% 1) l'equation de la chaleur suivante stationnaire, avec condition de
% Dirichlet non homogene
%
% | \alpha T - div(\sigma \grad T)= S,   dans \Omega=\Omega_1 U \Omega_2
% |         T = T_\Gamma,   sur le bord
%
% ou S est la source de chaleur, T_\Gamma la temperature exterieure
% \alpha > 0 et
% \sigma = | \sigma_1 dans \Omega_1
%          | \sigma_2 dans \Omega_2
%
% 2) l'equation de la chaleur suivante stationnaire, avec condition de
% Fourier homogene
%
% | \alpha T - div(\sigma \grad T)= S,   dans \Omega=\Omega_1 U \Omega_2
% |         \sigma \grad T.n + \lambda(T - T_c) = 0,   sur le bord
%
% ou S est la source de chaleur, T_\c la temperature de ref du climatiseur
% \alpha > 0 , \lambda>0, et
% \sigma = | \sigma_1 dans \Omega_1
%          | \sigma_2 dans \Omega_2
%
% 3) l'equation de la chaleur dependant du temps avec condition de 
% Dirichlet non homogene
%
% | dT/dt - div(\sigma \grad T)= S,   dans \Omega=\Omega_1 U \Omega_2 et pour tout t< t_max
% |         T = T_\Gamma,   sur le bord et pour tout t< t_max
% |         T = T_0       dans \Omega et pour t=0  
%
% ou S est la source de chaleur, T_\Gamma la temperature exterieure,
% T_0 est la valeur initiale de la temp?rature
% \alpha > 0 et
% \sigma = | \sigma_1 dans \Omega_1
%          | \sigma_2 dans \Omega_2
% =====================================================
% Donnees du probleme
% ---------------------------------
h = 0.05;
system(['gmsh -2 -clmax ' num2str(h) ' -clmin ' num2str(h) ' geomChaleur.geo']);
nom_maillage = 'geomChaleur.msh' ;

validation = 'oui';
pb_stationnaire = 'oui';
pb_fourier = 'oui'
pb_temporel = 'oui';

if strcmp(validation,'oui')
    alpha = 1;
    T_Gamma = 0;
end

if strcmp(pb_stationnaire,'oui')
    alpha = 1;
    T_Gamma = 290;
end

if strcmp(pb_fourier,'oui')
    alpha = 1;
    T_Gamma = 290;
    lambda = 1;
end

if strcmp(pb_temporel,'oui')
    Tps_initial = 0;
    Tps_final = 1;
    delta_t = 0.01;
    alpha = 1/delta_t;
    N_t = (Tps_final-Tps_initial)/delta_t; % le nombre d'iterations necessaires
    T_Gamma = 280;
end


% lecture du maillage et affichage
% ---------------------------------
[Nbpt,Nbtri,Coorneu,Refneu,Numtri,Reftri]=lecture_msh(nom_maillage);

% ----------------------
% calcul des matrices EF
% ----------------------

% declarations
% ------------
KK = sparse(Nbpt,Nbpt); % matrice de rigidite
MM = sparse(Nbpt,Nbpt); % matrice de rigidite
LL = zeros(Nbpt,1);     % vecteur second membre

% boucle sur les triangles
% ------------------------
for l=1:Nbtri

  % calcul des matrices elementaires du triangle l 

   [Kel]=matK_elem(Coorneu(Numtri(l,1),:),Coorneu(Numtri(l,2),:),...
               Coorneu(Numtri(l,3),:),Reftri(l));

   [Mel]=matM_elem(Coorneu(Numtri(l,1),:),Coorneu(Numtri(l,2),:),...
               Coorneu(Numtri(l,3),:));

    % On fait l'assemblage de la matrice globale
    for i=1:3
        I = Numtri(l,i);
        for j=1:3
            J = Numtri(l,j);
            MM(I,J) = MM(I,J)+Mel(i,j);
            KK(I,J) = KK(I,J)+Kel(i,j);
        end %for j
    end % for i
end % for l

% Matrice EF
% -------------------------
AA = alpha*MM+KK;

% Calcul du second membre L
% -------------------------
FF = zeros(Nbpt,1);     % vecteur d'interpolation de f
for I=1:Nbpt
    FF(I,1) = f(Coorneu(I,1),Coorneu(I,2));
end
LL = MM*FF;

% Pseudo elimination
% ------------------
[AA,LL] = elimine(AA,LL,Refneu);

% inversion
% ----------
UU = (AA)\LL;

% visualisation
% -------------
figure;
affiche(UU+T_Gamma, Numtri, Coorneu, sprintf('Dirichlet approchee - %s', nom_maillage));

validation = 'oui';
% validation
% ----------
if strcmp(validation,'oui')
    UU_exact = sin(pi*Coorneu(:,1)).*sin(pi*Coorneu(:,2));
    % Calcul de l erreur L2
    l2 = sqrt((UU-UU_exact)'*(MM*(UU-UU_exact)));
    % Calcul de l erreur H1
    h1 = sqrt((UU-UU_exact)'*(KK*(UU-UU_exact)));
end


%% =====================================================
% =====================================================
% Pour le probleme stationnaire avec conditions de Fourier
% ---------------------------------

if strcmp(pb_fourier,'oui')
    if strcmp(validation,'oui')
        alpha = 1;
        T_Gamma = 0;
        lambda = 0;
        %S(x,y) = cos(pi*x)*cos(pi*y)
        %sigma = 1
        
    end

    if strcmp(pb_stationnaire,'oui')
        alpha = 1;
        T_Gamma = 290;
    end
    % lecture du maillage et affichage
    % ---------------------------------
    [Nbpt,Nbtri,Coorneu,Refneu,Numtri,Reftri,Nbaretes,Numaretes,Refaretes]=lecture_msh(nom_maillage);

    % ----------------------
    % calcul des matrices EF
    % ----------------------

    % declarations
    % ------------
    KK = sparse(Nbpt,Nbpt); % matrice de rigidite
    MM = sparse(Nbpt,Nbpt); % matrice de masse
    SS = sparse(Nbpt,Nbpt); % matrice de masse surfacique
    LL = zeros(Nbpt,1);     % vecteur second membre

    % boucle sur les triangles
    % ------------------------
    for l=1:Nbtri
      % calcul des matrices elementaires du triangle l 
       [Kel]=matK_elem(Coorneu(Numtri(l,1),:),Coorneu(Numtri(l,2),:),...
                   Coorneu(Numtri(l,3),:),Reftri(l));

       [Mel]=matM_elem(Coorneu(Numtri(l,1),:),Coorneu(Numtri(l,2),:),...
                   Coorneu(Numtri(l,3),:));

        % On fait l'assemblage de la matrice globale
        for i=1:3
            I = Numtri(l,i);
            for j=1:3
                J = Numtri(l,j);
                MM(I,J) = MM(I,J)+Mel(i,j);
                KK(I,J) = KK(I,J)+Kel(i,j);
            end %for j
        end % for i
    end % for l

    % boucle sur les aretes
    % ------------------------
    for a = 1:Nbaretes
        % calcul des matrices elementaires de l'arete a
        [Sel] = mat_elem_surface(Coorneu(Numaretes(a,1),:),Coorneu(Numaretes(a,2),:),Refaretes(a));
        for i=1:2
            I = Numaretes(a,i);
            for j=1:2
                J = Numaretes(a,j);
                SS(I,J) = SS(I,J)+Sel(i,j);
            end
        end
    end

    % Matrice EF
    % -------------------------
    AA = alpha*MM+KK+lambda*SS;

    % Calcul du second membre L
    % -------------------------
    FF = zeros(Nbpt,1);     % vecteur d'interpolation de f
    Uc = zeros(Nbpt,1);     % vecteur d'interpolation de uc
    for I=1:Nbpt
        FF(I,1) = f(Coorneu(I,1),Coorneu(I,2));
        if Refneu(I)==1 % condition au bord du second membre
            Uc(I,1) = 290;  %Tc(Coorneu(I,1),Coorneu(I,2));
        end
    end
    LL = lambda*SS*Uc + MM*FF;


    % inversion
    % ----------
    UU = (AA)\LL;

    % visualisation
    % -------------
    affiche(UU, Numtri, Coorneu, sprintf('Fourier aprochee - %s', nom_maillage));

    validation = 'oui';
    % validation
    % ----------
    if strcmp(validation,'oui')
        UU_exact = cos(pi*Coorneu(:,1)).*cos(pi*Coorneu(:,2));
        % Calcul de l erreur L2
        l2 = sqrt((UU-UU_exact)'*(MM*(UU-UU_exact)));
        % Calcul de l erreur H1
        h1 = sqrt((UU-UU_exact)'*(KK*(UU-UU_exact)));
    end
end


 %% =====================================================
% =====================================================
% Pour le probleme temporel
% ---------------------------------
if strcmp(pb_temporel,'oui')

    % on initialise la condition initiale
    % -----------------------------------
    T_initial = condition_initiale(Coorneu(:,1),Coorneu(:,2));

	% solution a t=0
	% --------------
    UU = T_initial-T_Gamma;
    TT = T_initial;

    % visualisation
    % -------------
    figure;
    hold on;
    affiche(TT, Numtri, Coorneu, ['Temps = ', num2str(0)]);
%     axis([min(Coorneu(:,1)),max(Coorneu(:,1)),min(Coorneu(:,2)),max(Coorneu(:,2)),...
%         290,330,290,300]);
    hold off;
    
    % boucle sur les triangles
    % ------------------------
    for l=1:Nbtri
      % calcul des matrices elementaires du triangle l 
       [Kel]=matK_elem(Coorneu(Numtri(l,1),:),Coorneu(Numtri(l,2),:),...
                   Coorneu(Numtri(l,3),:),Reftri(l));

       [Mel]=matM_elem(Coorneu(Numtri(l,1),:),Coorneu(Numtri(l,2),:),...
                   Coorneu(Numtri(l,3),:));
        
        % On fait l'assemblage de la matrice globale
        for i=1:3
            I = Numtri(l,i);
            for j=1:3
                J = Numtri(l,j);
                MM(I,J) = MM(I,J)+Mel(i,j);
                KK(I,J) = KK(I,J)+Kel(i,j);
            end %for j
        end % for i
    end % for l
    
    % Calcul de AA
    AA = MM + delta_t*KK;
    
	% Boucle sur les pas de temps
	% ---------------------------
    for k = 1:N_t
        % Calcul du second membre F a l instant k*delta t
        % -----------------------------------------------
        LL_k = f_t(Coorneu(:,1),Coorneu(:,2),k*delta_t);
        %affiche(LL_k, Numtri, Coorneu, ['Temps = ', num2str(0)]);
        LL_k = delta_t*LL_k + MM*UU;
        
        
		% inversion
		% ----------
		% tilde_AA ET tilde_LL_k SONT LA MATRICE EF ET LE VECTEUR SECOND MEMBRE
		% APRES PSEUDO_ELIMINATION 
        [tilde_AA,tilde_LL_k] = elimine(AA,LL_k,Refneu);
        UU = tilde_AA\tilde_LL_k;
        TT = UU+T_Gamma;

        % visualisation 
		% -------------
        pause(0.1)
        if k==1 
            figure;
        elseif k ==2 
            figure;
        elseif k ==3
            figure;
        elseif k ==4 
            figure;
        elseif k ==10 
            figure;
        elseif k ==99
            figure;
        end 
        affiche(TT, Numtri, Coorneu, ['Temps = ', num2str(k*delta_t)]);
%         axis([min(Coorneu(:,1)),max(Coorneu(:,1)),min(Coorneu(:,2)),max(Coorneu(:,2)),...
%               280,340,280,340]);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                        fin de la routine
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

